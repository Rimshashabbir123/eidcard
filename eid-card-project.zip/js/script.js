// Stars
const starsEl = document.getElementById('stars');
for (let i = 0; i < 120; i++) {
  const s = document.createElement('div');
  s.className = 'star';
  s.style.left = Math.random()*100 + '%';
  s.style.top = Math.random()*100 + '%';
  starsEl.appendChild(s);
}